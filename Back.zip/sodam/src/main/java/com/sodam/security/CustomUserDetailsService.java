package com.sodam.security;

import com.sodam.domain.MemberDomain;
import com.sodam.repository.MemberRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final MemberRepository memberRepository;

    @Override
    public UserDetails loadUserByUsername(String id) throws UsernameNotFoundException {
        MemberDomain member = memberRepository.findById(id)
            .orElseThrow(() -> new UsernameNotFoundException("존재하지 않는 사용자입니다: " + id));

        System.out.println("🔥 로그인 시도: " + member.getId() + ", 권한: " + member.getAuthorization());

        return User.builder()
        	    .username(member.getId())
        	    .password(member.getPassword()) // ← 해시된 값 들어가야 함
        	    .roles(member.getAuthorization().equals("A") ? "ADMIN" : "USER")
        	    .build();

    }
}
