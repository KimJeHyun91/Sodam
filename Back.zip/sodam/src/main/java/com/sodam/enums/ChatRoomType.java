package com.sodam.enums;

public enum ChatRoomType {
    ONE_TO_ONE,
    BLUETOOTH_GROUP,
    OPEN_GROUP
}
