package com.sodam.dto;

import lombok.Data;

@Data
public class EmailDto {
    private String email;
}
